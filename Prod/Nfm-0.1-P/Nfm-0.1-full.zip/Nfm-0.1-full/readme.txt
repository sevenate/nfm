
Nfm 0.1 for Windows XP/2003/Vista/2008/Seven
-----------------------
Date: 22 June 09

Warning: This software has a PREVIEW quality! Use it for your own risk.

Nfm is a data manager for Windows, a tool like the Explorer or file manager,
which comes with windows. But Nfm uses a different approach:
it has "tabs and stacks" interface - all opened windows are organized with tab controls
and stack panels, which makes file browsing much easier and also allow you to orginize
your workspace with all frequently used folders in convenient and accessible way.

Nfm requires installed Microsoft .NET Framework 3.5 Service Pack 1.
Online installer could be downloaded from here: http://go.microsoft.com/fwlink/?linkid=124150
Note: this additional step is not required for Windows Seven.

Nfm is shareware. The shareware version is freely distributable, 
as long as it is unchanged!

Here some key features of Nfm:

- Local file system browser with support of logical drives, folders and files
- Launch any file to execution
- Context menu for files and folders
- Tabs drag'n'drop

See changelog.txt for more info.

Andrey Levshov     e-mail: support@localhost
HD Software           WWW: http://localhost